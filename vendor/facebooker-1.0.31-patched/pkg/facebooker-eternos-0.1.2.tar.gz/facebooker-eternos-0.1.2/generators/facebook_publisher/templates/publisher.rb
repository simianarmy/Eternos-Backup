class <%= class_name %>Publisher < Facebooker::Rails::Publisher
  
end
